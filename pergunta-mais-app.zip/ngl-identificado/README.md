# Pergunta+ — mensagens identificadas

Aplicativo web inspirado em caixas de perguntas, com cadastro, login, perfil público, envio de mensagens identificadas e caixa de entrada privada.

## Como executar no computador

1. Instale Node.js 18 ou superior.
2. Extraia o ZIP e abra um terminal dentro da pasta `ngl-identificado`.
3. Execute `npm install`.
4. Execute `npm start`.
5. Abra `http://localhost:3000`.

O banco SQLite (`data.sqlite`) será criado automaticamente.

## Como usar

- Crie uma conta com nome, usuário, e-mail e senha.
- Compartilhe o link `http://SEU-ENDERECO/u/SEU_USUARIO`.
- A pessoa que abrir o link precisa entrar ou criar uma conta antes de enviar.
- A caixa de entrada mostra nome, usuário, foto de perfil (se cadastrada) e mensagem.

## Publicar na internet

Publique em um serviço que rode Node.js e tenha armazenamento persistente para `data.sqlite`. Configure:
- `SESSION_SECRET`: uma chave longa e aleatória.
- `NODE_ENV=production`.
- HTTPS obrigatório em produção.

Não use armazenamento efêmero para SQLite, pois o banco pode ser perdido quando o serviço reiniciar. Para tráfego maior, migre para PostgreSQL e armazenamento de sessão persistente.

## Privacidade e limites

Este app não identifica remetentes anônimos de outros serviços. A identidade é exibida porque cada remetente precisa entrar em sua conta, e a tela de envio informa isso claramente. O painel é privado por sessão; não existe senha mestra ou acesso secreto. Use apenas dados e fotos que você tem direito de utilizar.
