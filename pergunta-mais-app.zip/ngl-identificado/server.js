const express = require("express");
const session = require("express-session");
const Database = require("better-sqlite3");
const crypto = require("crypto");
const path = require("path");

const app = express();
const db = new Database("data.sqlite");
const PORT = process.env.PORT || 3000;
const SESSION_SECRET = process.env.SESSION_SECRET || "troque-esta-chave-antes-de-publicar";

db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT UNIQUE NOT NULL,
 display_name TEXT NOT NULL,
 email TEXT UNIQUE NOT NULL,
 avatar TEXT DEFAULT '',
 salt TEXT NOT NULL,
 password_hash TEXT NOT NULL,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS messages (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 sender_id INTEGER NOT NULL REFERENCES users(id),
 recipient_id INTEGER NOT NULL REFERENCES users(id),
 body TEXT NOT NULL,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP,
 read_at TEXT
);
`);

app.use(express.json({limit:"1mb"}));
app.use(express.urlencoded({extended:false}));
app.use(session({
 secret: SESSION_SECRET, resave:false, saveUninitialized:false,
 cookie:{ httpOnly:true, sameSite:"lax", secure:process.env.NODE_ENV==="production", maxAge:7*24*60*60*1000 }
}));
app.use(express.static(path.join(__dirname,"public")));

function hashPassword(password, salt) {
 return crypto.scryptSync(password, salt, 64).toString("hex");
}
function safeUser(row) {
 return row && {id:row.id, username:row.username, displayName:row.display_name, email:row.email, avatar:row.avatar || ""};
}
function auth(req,res,next) {
 if (!req.session.userId) return res.status(401).json({error:"Entre na sua conta para continuar."});
 next();
}
function validUsername(s) { return /^[a-zA-Z0-9_]{3,20}$/.test(s); }

app.post("/api/register", (req,res) => {
 const {username, displayName, email, password, avatar=""} = req.body || {};
 if (!validUsername(username || "")) return res.status(400).json({error:"Usuário: use 3 a 20 letras, números ou _."});
 if (!displayName || displayName.trim().length < 2 || displayName.length > 40) return res.status(400).json({error:"Informe um nome entre 2 e 40 caracteres."});
 if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email || "")) return res.status(400).json({error:"E-mail inválido."});
 if (typeof password !== "string" || password.length < 8) return res.status(400).json({error:"A senha precisa ter pelo menos 8 caracteres."});
 if (avatar && (!/^https:\/\/.{5,500}$/.test(avatar))) return res.status(400).json({error:"A foto deve ser um link HTTPS válido."});
 const salt = crypto.randomBytes(16).toString("hex");
 try {
  const info = db.prepare("INSERT INTO users(username,display_name,email,avatar,salt,password_hash) VALUES(?,?,?,?,?,?)")
   .run(username.toLowerCase(), displayName.trim(), email.toLowerCase(), avatar, salt, hashPassword(password,salt));
  req.session.userId = Number(info.lastInsertRowid);
  res.json({user:safeUser(db.prepare("SELECT * FROM users WHERE id=?").get(req.session.userId))});
 } catch(e) { res.status(409).json({error:"Este usuário ou e-mail já está cadastrado."}); }
});

app.post("/api/login", (req,res) => {
 const {email,password} = req.body || {};
 const user = db.prepare("SELECT * FROM users WHERE email=?").get(String(email||"").toLowerCase());
 if (!user || hashPassword(String(password||""),user.salt) !== user.password_hash)
  return res.status(401).json({error:"E-mail ou senha incorretos."});
 req.session.userId = user.id;
 res.json({user:safeUser(user)});
});
app.post("/api/logout", (req,res) => req.session.destroy(()=>res.json({ok:true})));
app.get("/api/me", (req,res) => {
 if (!req.session.userId) return res.json({user:null});
 res.json({user:safeUser(db.prepare("SELECT * FROM users WHERE id=?").get(req.session.userId))});
});
app.get("/api/profile/:username", (req,res) => {
 const u = db.prepare("SELECT username,display_name,avatar FROM users WHERE username=?").get(req.params.username.toLowerCase());
 if (!u) return res.status(404).json({error:"Perfil não encontrado."});
 res.json({profile:{username:u.username,displayName:u.display_name,avatar:u.avatar}});
});
app.post("/api/messages/:username", auth, (req,res) => {
 const recipient = db.prepare("SELECT id FROM users WHERE username=?").get(req.params.username.toLowerCase());
 if (!recipient) return res.status(404).json({error:"Perfil não encontrado."});
 const body = String(req.body.body || "").trim();
 if (!body || body.length > 1000) return res.status(400).json({error:"A mensagem deve ter de 1 a 1000 caracteres."});
 if (recipient.id === req.session.userId) return res.status(400).json({error:"Você não pode enviar mensagem para si mesmo."});
 const info = db.prepare("INSERT INTO messages(sender_id,recipient_id,body) VALUES(?,?,?)").run(req.session.userId,recipient.id,body);
 res.json({ok:true,id:Number(info.lastInsertRowid),notice:"Mensagem enviada. Seu nome e sua foto serão exibidos ao destinatário."});
});
app.get("/api/inbox", auth, (req,res) => {
 const rows = db.prepare(`
 SELECT m.id,m.body,m.created_at,m.read_at,u.username,u.display_name,u.avatar
 FROM messages m JOIN users u ON u.id=m.sender_id
 WHERE m.recipient_id=? ORDER BY m.id DESC
 `).all(req.session.userId);
 res.json({messages:rows});
});
app.patch("/api/messages/:id/read", auth, (req,res) => {
 const result = db.prepare("UPDATE messages SET read_at=CURRENT_TIMESTAMP WHERE id=? AND recipient_id=?").run(Number(req.params.id),req.session.userId);
 if (!result.changes) return res.status(404).json({error:"Mensagem não encontrada."});
 res.json({ok:true});
});
app.delete("/api/messages/:id", auth, (req,res) => {
 const result = db.prepare("DELETE FROM messages WHERE id=? AND recipient_id=?").run(Number(req.params.id),req.session.userId);
 if (!result.changes) return res.status(404).json({error:"Mensagem não encontrada."});
 res.json({ok:true});
});

app.get("*", (req,res) => res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT, () => console.log(`App disponível em http://localhost:${PORT}`));
